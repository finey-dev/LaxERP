<div class="modal-body">
    <div class="row">
        <div class="form-group">
            <label for="">{{ $spreadsheet->folder_name}}</label>
        </div>
    </div>
</div>
