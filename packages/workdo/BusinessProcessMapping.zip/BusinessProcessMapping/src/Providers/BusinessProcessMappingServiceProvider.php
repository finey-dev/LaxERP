<?php

namespace Workdo\BusinessProcessMapping\Providers;

use Illuminate\Support\ServiceProvider;
use Workdo\BusinessProcessMapping\Providers\EventServiceProvider;
use Workdo\BusinessProcessMapping\Providers\RouteServiceProvider;

class BusinessProcessMappingServiceProvider extends ServiceProvider
{

    protected $moduleName = 'BusinessProcessMapping';
    protected $moduleNameLower = 'businessprocessmapping';

    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(EventServiceProvider::class);
    }

    public function boot()
    {
        $this->loadRoutesFrom(__DIR__ . '/../Routes/web.php');
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', 'business-process-mapping');
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
        $this->registerTranslations();
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $langPath = resource_path('lang/modules/' . $this->moduleNameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->moduleNameLower);
            $this->loadJsonTranslationsFrom($langPath);
        } else {
            $this->loadTranslationsFrom(__DIR__.'/../Resources/lang', $this->moduleNameLower);
            $this->loadJsonTranslationsFrom(__DIR__.'/../Resources/lang');
        }
    }
}