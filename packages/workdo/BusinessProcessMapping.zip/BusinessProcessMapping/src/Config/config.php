<?php

return [
    'name' => 'BusinessProcessMapping'
];
