<?php

namespace Workdo\MarketingPlan\Entities;

use Illuminate\Database\Eloquent\Model;

class SocialMediaTokens extends Model
{
    protected $fillable = [
        'token',
        'expiry',
        'platform',
        'refresh_token',
        'user_id',
        'workspace_id',
    ];

}
