<?php

namespace Workdo\MarketingPlan\Http\Controllers;

use Workdo\MarketingPlan\Http\Controllers\MarketingIntegrationController;

class FacebookController extends MarketingIntegrationController
{

}
