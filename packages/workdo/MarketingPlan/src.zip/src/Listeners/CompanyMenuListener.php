<?php

namespace Workdo\MarketingPlan\Listeners;

use App\Events\CompanyMenuEvent;

class CompanyMenuListener
{
    /**
     * Handle the event.
     */
    public function handle(CompanyMenuEvent $event): void
    {
        $module = 'MarketingPlan';
        $menu = $event->menu;
        $menu->add([
            'category' => 'Productivity',
            'title' => __('Marketing Plan'),
            'icon' => '',
            'name' => 'marketing-plan',
            'parent' => 'planning',
            'order' => 22,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'marketing-plan.index',
            'module' => $module,
            'permission' => 'marketing plan manage'
        ]);
        $menu->add([
            'category' => 'Productivity',
            'title' => __('Ad Management'),
            'icon' => '',
            'name' => 'ad-management',
            'parent' => 'planning',
            'order' => 23,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'marketing-social.facebook',
            'module' => $module,
            'permission' => 'marketing plan manage'
        ]);
        $menu->add([
            'category' => 'Productivity',
            'title' => __('Facebook'),
            'icon' => '',
            'name' => 'facebook',
            'parent' => 'ad-management',
            'order' => 24,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'marketing-social.facebook',
            'module' => $module,
            'permission' => 'marketing plan manage'
        ]);
        $menu->add([
            'category' => 'Productivity',
            'title' => __('Google'),
            'icon' => '',
            'name' => 'google',
            'parent' => 'ad-management',
            'order' => 25,
            'ignore_if' => [],
            'depend_on' => [],
            'route' => 'marketing-social.google',
            'module' => $module,
            'permission' => 'marketing plan manage'
        ]);
    }
}
