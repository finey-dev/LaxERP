<?php

return [
    'name' => 'Internalknowledge'
];
