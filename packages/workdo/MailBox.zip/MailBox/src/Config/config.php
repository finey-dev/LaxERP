<?php

return [
    'name' => 'MailBox'
];
