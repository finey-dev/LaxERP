@permission('salesagent manage')
    <a href="#salesagent-sidenav" class="list-group-item list-group-item-action">
       {{ __('Sales Agent Settings') }}
       <div class="float-end"><i class="ti ti-chevron-right"></i></div>
    </a>
@endpermission


