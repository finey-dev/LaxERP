@extends('layouts.main')

@section('page-title')
    {{__('Sales Agent')}}
@endsection

@section('page-breadcrumb')
    {{ __('Sales Agent')}} ,{{ __('Orders')}}
@endsection

@section('content')



@endsection
